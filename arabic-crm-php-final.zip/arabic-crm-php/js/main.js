// Main JavaScript File for Arabic CRM

// Global variables
let currentPage = 'dashboard';
let selectedItem = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Initialize event listeners
    initializeModals();
    initializeForms();
    initializeDeleteButtons();
    
    // Close alerts automatically
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 300);
        });
    }, 5000);
}

// Modal Functions
function initializeModals() {
    // Close modal when clicking outside
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal(this.id);
            }
        });
    });
    
    // Close modal buttons
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            closeModal(modal.id);
        });
    });
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
        
        // Reset form if exists
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
        }
    }
}

// Form Functions
function initializeForms() {
    // Add form submission handlers
    document.querySelectorAll('form[data-ajax]').forEach(form => {
        form.addEventListener('submit', handleAjaxForm);
    });
}

async function handleAjaxForm(e) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData(form);
    const action = form.action;
    
    try {
        const response = await fetch(action, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert('success', result.message);
            
            // Close modal if form is inside one
            const modal = form.closest('.modal');
            if (modal) {
                closeModal(modal.id);
            }
            
            // Reload page after short delay
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            showAlert('error', result.message);
        }
    } catch (error) {
        showAlert('error', 'حدث خطأ أثناء معالجة الطلب');
        console.error('Form submission error:', error);
    }
}

// Alert Functions
function showAlert(type, message) {
    const alertClass = type === 'success' ? 'alert-success' : 'alert-error';
    const icon = type === 'success' ? '✓' : '✗';
    
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} fade-in`;
    alert.innerHTML = `
        <span>${icon}</span>
        <span>${message}</span>
    `;
    
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        mainContent.insertBefore(alert, mainContent.firstChild);
        
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 300);
        }, 5000);
    }
}

// Delete Functions
function initializeDeleteButtons() {
    document.querySelectorAll('[data-delete]').forEach(btn => {
        btn.addEventListener('click', handleDelete);
    });
}

async function handleDelete(e) {
    e.preventDefault();
    
    if (!confirm('هل أنت متأكد من الحذف؟')) {
        return;
    }
    
    const btn = e.currentTarget;
    const url = btn.dataset.delete;
    
    try {
        const response = await fetch(url, {
            method: 'POST'
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert('success', result.message);
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            showAlert('error', result.message);
        }
    } catch (error) {
        showAlert('error', 'حدث خطأ أثناء الحذف');
        console.error('Delete error:', error);
    }
}

// Product Functions
function openProductModal(productId = null) {
    if (productId) {
        // Load product data
        fetch(`php/products.php?action=get&id=${productId}`)
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    fillProductForm(result.data);
                }
            });
    }
    openModal('productModal');
}

function fillProductForm(product) {
    document.getElementById('product_id').value = product.id;
    document.getElementById('name').value = product.name;
    document.getElementById('category').value = product.category;
    document.getElementById('size').value = product.size;
    document.getElementById('color').value = product.color;
    document.getElementById('sku').value = product.sku;
    document.getElementById('stock').value = product.stock;
    document.getElementById('cost_price').value = product.cost_price;
    document.getElementById('selling_price').value = product.selling_price;
    document.getElementById('image').value = product.image;
    document.getElementById('notes').value = product.notes;
}

// Customer Functions
function openCustomerModal(customerId = null) {
    if (customerId) {
        fetch(`php/customers.php?action=get&id=${customerId}`)
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    fillCustomerForm(result.data);
                }
            });
    }
    openModal('customerModal');
}

function fillCustomerForm(customer) {
    document.getElementById('customer_id').value = customer.id;
    document.getElementById('full_name').value = customer.full_name;
    document.getElementById('phone').value = customer.phone;
    document.getElementById('address').value = customer.address;
    document.getElementById('city').value = customer.city;
    document.getElementById('notes').value = customer.notes;
}

// Order Functions
let orderItems = [];

function openOrderModal(orderId = null) {
    orderItems = [];
    if (orderId) {
        fetch(`php/orders.php?action=get&id=${orderId}`)
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    fillOrderForm(result.data);
                    orderItems = result.data.items;
                    updateOrderItemsTable();
                }
            });
    }
    openModal('orderModal');
}

function addOrderItem() {
    const productSelect = document.getElementById('order_product');
    const quantityInput = document.getElementById('order_quantity');
    
    const productId = productSelect.value;
    const quantity = parseInt(quantityInput.value);
    
    if (!productId || quantity <= 0) {
        showAlert('error', 'يرجى اختيار المنتج وإدخال الكمية');
        return;
    }
    
    const selectedOption = productSelect.options[productSelect.selectedIndex];
    const productName = selectedOption.text;
    const unitPrice = parseFloat(selectedOption.dataset.price);
    const costPrice = parseFloat(selectedOption.dataset.cost);
    
    const existingItem = orderItems.find(item => item.product_id === productId);
    
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        orderItems.push({
            product_id: productId,
            product_name: productName,
            quantity: quantity,
            unit_price: unitPrice,
            cost_price: costPrice
        });
    }
    
    updateOrderItemsTable();
    quantityInput.value = 1;
}

function removeOrderItem(index) {
    orderItems.splice(index, 1);
    updateOrderItemsTable();
}

function updateOrderItemsTable() {
    const tbody = document.getElementById('orderItemsTable');
    const itemsInput = document.getElementById('order_items');
    
    if (!tbody) return;
    
    tbody.innerHTML = '';
    let subtotal = 0;
    
    orderItems.forEach((item, index) => {
        const total = item.quantity * item.unit_price;
        subtotal += total;
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.product_name}</td>
            <td>${item.quantity}</td>
            <td>${item.unit_price.toFixed(2)} ج.م</td>
            <td>${total.toFixed(2)} ج.م</td>
            <td>
                <button type="button" class="btn btn-danger btn-sm" onclick="removeOrderItem(${index})">
                    حذف
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
    
    // Update hidden input
    itemsInput.value = JSON.stringify(orderItems);
    
    // Calculate total
    const discount = parseFloat(document.getElementById('discount')?.value || 0);
    const shippingCost = parseFloat(document.getElementById('shipping_cost')?.value || 0);
    const total = subtotal - discount + shippingCost;
    
    document.getElementById('orderSubtotal').textContent = subtotal.toFixed(2) + ' ج.م';
    document.getElementById('orderTotal').textContent = total.toFixed(2) + ' ج.م';
}

// Expense Functions
function openExpenseModal(expenseId = null) {
    if (expenseId) {
        fetch(`php/expenses.php?action=get&id=${expenseId}`)
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    fillExpenseForm(result.data);
                }
            });
    }
    openModal('expenseModal');
}

function fillExpenseForm(expense) {
    document.getElementById('expense_id').value = expense.id;
    document.getElementById('type').value = expense.type;
    document.getElementById('amount').value = expense.amount;
    document.getElementById('expense_date').value = expense.expense_date;
    document.getElementById('notes').value = expense.notes;
}

// Utility Functions
function formatCurrency(amount) {
    return parseFloat(amount).toFixed(2) + ' ج.م';
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-EG');
}

// Print Functions
function printInvoice(invoiceId) {
    window.open(`print_invoice.php?id=${invoiceId}`, '_blank');
}

function printReport() {
    window.print();
}

// Search and Filter Functions
function searchTable(inputId, tableId) {
    const input = document.getElementById(inputId);
    const table = document.getElementById(tableId);
    const filter = input.value.toUpperCase();
    const rows = table.getElementsByTagName('tr');
    
    for (let i = 1; i < rows.length; i++) {
        let found = false;
        const cells = rows[i].getElementsByTagName('td');
        
        for (let j = 0; j < cells.length; j++) {
            const cell = cells[j];
            if (cell) {
                const textValue = cell.textContent || cell.innerText;
                if (textValue.toUpperCase().indexOf(filter) > -1) {
                    found = true;
                    break;
                }
            }
        }
        
        rows[i].style.display = found ? '' : 'none';
    }
}

function filterTable(selectId, tableId, columnIndex) {
    const select = document.getElementById(selectId);
    const table = document.getElementById(tableId);
    const filter = select.value.toUpperCase();
    const rows = table.getElementsByTagName('tr');
    
    for (let i = 1; i < rows.length; i++) {
        const cell = rows[i].getElementsByTagName('td')[columnIndex];
        
        if (cell) {
            const textValue = cell.textContent || cell.innerText;
            if (filter === '' || textValue.toUpperCase().indexOf(filter) > -1) {
                rows[i].style.display = '';
            } else {
                rows[i].style.display = 'none';
            }
        }
    }
}

// Export Functions
function exportToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    let csv = [];
    const rows = table.querySelectorAll('tr');
    
    for (let i = 0; i < rows.length; i++) {
        const row = [];
        const cols = rows[i].querySelectorAll('td, th');
        
        for (let j = 0; j < cols.length - 1; j++) { // Exclude last column (actions)
            row.push(cols[j].innerText);
        }
        
        csv.push(row.join(','));
    }
    
    const csvFile = new Blob([csv.join('\n')], { type: 'text/csv' });
    const downloadLink = document.createElement('a');
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}

// Dashboard Chart (if using Chart.js)
function initializeDashboardChart(data) {
    const ctx = document.getElementById('salesChart');
    if (!ctx) return;
    
    // Chart implementation would go here
    // This would require Chart.js library
}
