<?php
require_once 'includes/config.php';
require_once 'includes/database.php';
require_once 'includes/functions.php';

requireLogin();

// Get dashboard statistics
try {
    $db = getDB();
    
    // Today's orders
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM orders WHERE DATE(order_date) = CURDATE()");
    $stmt->execute();
    $todayOrders = $stmt->fetch()['count'];
    
    // Pending orders
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM orders WHERE status IN ('new', 'processing')");
    $stmt->execute();
    $pendingOrders = $stmt->fetch()['count'];
    
    // Low stock products
    $stmt = $db->prepare("SELECT * FROM products WHERE stock <= 10 ORDER BY stock ASC LIMIT 10");
    $stmt->execute();
    $lowStockProducts = $stmt->fetchAll();
    
    // Calculate sales and profit
    $stmt = $db->prepare("
        SELECT 
            SUM(oi.quantity * oi.unit_price) as total_sales,
            SUM(oi.quantity * oi.cost_price) as total_cost,
            SUM(o.shipping_cost) as total_shipping,
            SUM(o.discount) as total_discount
        FROM orders o
        LEFT JOIN order_items oi ON o.id = oi.order_id
        WHERE o.status NOT IN ('cancelled', 'returned')
    ");
    $stmt->execute();
    $salesData = $stmt->fetch();
    
    $totalSales = ($salesData['total_sales'] ?? 0) + ($salesData['total_shipping'] ?? 0) - ($salesData['total_discount'] ?? 0);
    $totalCost = $salesData['total_cost'] ?? 0;
    $totalProfit = $totalSales - $totalCost;
    
    // Total expenses
    $stmt = $db->prepare("SELECT SUM(amount) as total FROM expenses");
    $stmt->execute();
    $totalExpenses = $stmt->fetch()['total'] ?? 0;
    
    $netProfit = $totalProfit - $totalExpenses;
    
    // Today's profit
    $stmt = $db->prepare("
        SELECT 
            SUM(oi.quantity * (oi.unit_price - oi.cost_price)) as profit,
            SUM(o.discount) as discount
        FROM orders o
        LEFT JOIN order_items oi ON o.id = oi.order_id
        WHERE DATE(o.order_date) = CURDATE()
        AND o.status NOT IN ('cancelled', 'returned')
    ");
    $stmt->execute();
    $todayData = $stmt->fetch();
    $todayProfit = ($todayData['profit'] ?? 0) - ($todayData['discount'] ?? 0);
    
    // Recent orders
    $stmt = $db->prepare("
        SELECT o.*, c.full_name as customer_name
        FROM orders o
        LEFT JOIN customers c ON o.customer_id = c.id
        ORDER BY o.order_date DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recentOrders = $stmt->fetchAll();
    
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

$pageTitle = 'لوحة التحكم';
$currentPage = 'dashboard';
include 'includes/header.php';
?>

<div class="page-header">
    <h1 class="page-title">لوحة التحكم</h1>
</div>

<?php if ($success = getSuccessMessage()): ?>
    <div class="alert alert-success">
        <span>✓</span>
        <span><?php echo $success; ?></span>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon pink">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                <polyline points="7 10 12 15 17 10"/>
                <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">طلبات اليوم</div>
            <div class="stat-value"><?php echo $todayOrders; ?></div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon green">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="12" y1="1" x2="12" y2="23"/>
                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">ربح اليوم</div>
            <div class="stat-value"><?php echo formatCurrency($todayProfit); ?></div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon yellow">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12 6 12 12 16 14"/>
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">طلبات قيد المعالجة</div>
            <div class="stat-value"><?php echo $pendingOrders; ?></div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon blue">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="12" y1="1" x2="12" y2="23"/>
                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
            </svg>
        </div>
        <div class="stat-content">
            <div class="stat-label">صافي الربح</div>
            <div class="stat-value"><?php echo formatCurrency($netProfit); ?></div>
        </div>
    </div>
</div>

<!-- Recent Orders -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">أحدث الطلبات</h2>
        <a href="orders.php" class="btn btn-primary btn-sm">عرض الكل</a>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>رقم الطلب</th>
                    <th>العميل</th>
                    <th>التاريخ</th>
                    <th>الحالة</th>
                    <th>المبلغ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentOrders as $order): ?>
                    <?php
                    // Calculate order total
                    $stmt = $db->prepare("
                        SELECT SUM(quantity * unit_price) as subtotal
                        FROM order_items
                        WHERE order_id = ?
                    ");
                    $stmt->execute([$order['id']]);
                    $subtotal = $stmt->fetch()['subtotal'] ?? 0;
                    $total = $subtotal + $order['shipping_cost'] - $order['discount'];
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($order['order_number']); ?></td>
                        <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                        <td><?php echo formatDateTime($order['order_date']); ?></td>
                        <td>
                            <span class="badge badge-<?php echo $order['status']; ?>">
                                <?php echo getStatusLabel($order['status']); ?>
                            </span>
                        </td>
                        <td><?php echo formatCurrency($total); ?></td>
                    </tr>
                <?php endforeach; ?>
                
                <?php if (empty($recentOrders)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center;">لا توجد طلبات</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Low Stock Products -->
<?php if (!empty($lowStockProducts)): ?>
<div class="card">
    <div class="card-header">
        <h2 class="card-title">منتجات بمخزون منخفض</h2>
        <a href="products.php" class="btn btn-primary btn-sm">إدارة المنتجات</a>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>الصورة</th>
                    <th>الاسم</th>
                    <th>SKU</th>
                    <th>المخزون</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lowStockProducts as $product): ?>
                    <tr>
                        <td>
                            <?php if ($product['image']): ?>
                                <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($product['name']); ?>"
                                     class="product-image">
                            <?php else: ?>
                                <div class="product-image" style="background: #f3f4f6;"></div>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td><?php echo htmlspecialchars($product['sku']); ?></td>
                        <td>
                            <span style="color: <?php echo $product['stock'] <= 5 ? '#dc2626' : '#d97706'; ?>; font-weight: bold;">
                                <?php echo $product['stock']; ?>
                            </span>
                        </td>
                        <td>
                            <a href="products.php?edit=<?php echo $product['id']; ?>" class="btn btn-primary btn-sm">
                                تعديل
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
