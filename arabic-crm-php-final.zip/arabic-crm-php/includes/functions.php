<?php
require_once 'database.php';

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Check if user is admin
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

// Redirect if not logged in
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

// Redirect if not admin
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: index.php');
        exit;
    }
}

// Sanitize input
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

// Format currency
function formatCurrency($amount) {
    return number_format($amount, 2) . ' ج.م';
}

// Format date
function formatDate($date) {
    return date('Y-m-d', strtotime($date));
}

// Format datetime
function formatDateTime($datetime) {
    return date('Y-m-d H:i', strtotime($datetime));
}

// Generate unique ID
function generateUniqueId($prefix = '') {
    return $prefix . uniqid() . mt_rand(1000, 9999);
}

// Generate order number
function generateOrderNumber() {
    return 'ORD-' . date('Y') . '-' . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

// Generate invoice number
function generateInvoiceNumber() {
    return 'INV-' . date('Y') . '-' . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

// Category labels
function getCategoryLabel($category) {
    $labels = [
        'lingerie' => 'لانجري',
        'pajamas' => 'بيجامات',
        'sets' => 'أطقم',
        'accessories' => 'إكسسوارات'
    ];
    return $labels[$category] ?? $category;
}

// Status labels
function getStatusLabel($status) {
    $labels = [
        'new' => 'جديد',
        'processing' => 'قيد التجهيز',
        'shipped' => 'تم الشحن',
        'delivered' => 'تم التسليم',
        'cancelled' => 'ملغي',
        'returned' => 'مرتجع'
    ];
    return $labels[$status] ?? $status;
}

// Status colors
function getStatusColor($status) {
    $colors = [
        'new' => 'bg-blue-100 text-blue-700',
        'processing' => 'bg-yellow-100 text-yellow-700',
        'shipped' => 'bg-purple-100 text-purple-700',
        'delivered' => 'bg-green-100 text-green-700',
        'cancelled' => 'bg-red-100 text-red-700',
        'returned' => 'bg-gray-100 text-gray-700'
    ];
    return $colors[$status] ?? 'bg-gray-100 text-gray-700';
}

// Payment method labels
function getPaymentLabel($method) {
    $labels = [
        'cash' => 'كاش',
        'transfer' => 'تحويل بنكي',
        'online' => 'دفع إلكتروني'
    ];
    return $labels[$method] ?? $method;
}

// Shipping method labels
function getShippingLabel($method) {
    $labels = [
        'standard' => 'شحن عادي',
        'express' => 'شحن سريع',
        'pickup' => 'استلام من المحل'
    ];
    return $labels[$method] ?? $method;
}

// Expense type labels
function getExpenseLabel($type) {
    $labels = [
        'shipping' => 'شحن',
        'advertising' => 'إعلانات',
        'packaging' => 'تغليف',
        'photography' => 'تصوير',
        'operational' => 'مصاريف تشغيلية',
        'other' => 'أخرى'
    ];
    return $labels[$type] ?? $type;
}

// Success message
function setSuccessMessage($message) {
    $_SESSION['success_message'] = $message;
}

// Error message
function setErrorMessage($message) {
    $_SESSION['error_message'] = $message;
}

// Get and clear success message
function getSuccessMessage() {
    if (isset($_SESSION['success_message'])) {
        $message = $_SESSION['success_message'];
        unset($_SESSION['success_message']);
        return $message;
    }
    return null;
}

// Get and clear error message
function getErrorMessage() {
    if (isset($_SESSION['error_message'])) {
        $message = $_SESSION['error_message'];
        unset($_SESSION['error_message']);
        return $message;
    }
    return null;
}

// JSON response
function jsonResponse($success, $data = [], $message = '') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => $success,
        'data' => $data,
        'message' => $message
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
?>
