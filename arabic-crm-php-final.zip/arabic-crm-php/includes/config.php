<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'arabic_crm');

// Site Configuration
define('SITE_NAME', 'نظام إدارة لانجري');
define('SITE_URL', 'http://localhost/arabic-crm-php');
define('TIMEZONE', 'Africa/Cairo');

// Session Configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS

// Error Reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set Timezone
date_default_timezone_set(TIMEZONE);

// Start Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
