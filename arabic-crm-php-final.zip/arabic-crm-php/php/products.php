<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/functions.php';

requireLogin();

header('Content-Type: application/json; charset=utf-8');

$db = getDB();
$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    switch ($action) {
        case 'get':
            $id = $_GET['id'] ?? 0;
            $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$id]);
            $product = $stmt->fetch();
            
            if ($product) {
                jsonResponse(true, $product);
            } else {
                jsonResponse(false, [], 'المنتج غير موجود');
            }
            break;
            
        case 'list':
            $stmt = $db->query("SELECT * FROM products ORDER BY created_at DESC");
            $products = $stmt->fetchAll();
            jsonResponse(true, $products);
            break;
            
        case 'add':
        case 'update':
            $id = $_POST['id'] ?? 0;
            $name = sanitize($_POST['name'] ?? '');
            $category = $_POST['category'] ?? '';
            $size = sanitize($_POST['size'] ?? '');
            $color = sanitize($_POST['color'] ?? '');
            $sku = sanitize($_POST['sku'] ?? '');
            $stock = intval($_POST['stock'] ?? 0);
            $costPrice = floatval($_POST['cost_price'] ?? 0);
            $sellingPrice = floatval($_POST['selling_price'] ?? 0);
            $image = sanitize($_POST['image'] ?? '');
            $notes = sanitize($_POST['notes'] ?? '');
            
            // Validation
            if (empty($name) || empty($category) || empty($sku)) {
                jsonResponse(false, [], 'يرجى ملء جميع الحقول المطلوبة');
            }
            
            if ($action === 'add') {
                // Check if SKU exists
                $stmt = $db->prepare("SELECT id FROM products WHERE sku = ?");
                $stmt->execute([$sku]);
                if ($stmt->fetch()) {
                    jsonResponse(false, [], 'رمز SKU موجود بالفعل');
                }
                
                $stmt = $db->prepare("
                    INSERT INTO products (name, category, size, color, sku, stock, cost_price, selling_price, image, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$name, $category, $size, $color, $sku, $stock, $costPrice, $sellingPrice, $image, $notes]);
                jsonResponse(true, ['id' => $db->lastInsertId()], 'تم إضافة المنتج بنجاح');
            } else {
                // Check if SKU exists for other products
                $stmt = $db->prepare("SELECT id FROM products WHERE sku = ? AND id != ?");
                $stmt->execute([$sku, $id]);
                if ($stmt->fetch()) {
                    jsonResponse(false, [], 'رمز SKU موجود بالفعل');
                }
                
                $stmt = $db->prepare("
                    UPDATE products 
                    SET name = ?, category = ?, size = ?, color = ?, sku = ?, stock = ?, 
                        cost_price = ?, selling_price = ?, image = ?, notes = ?
                    WHERE id = ?
                ");
                $stmt->execute([$name, $category, $size, $color, $sku, $stock, $costPrice, $sellingPrice, $image, $notes, $id]);
                jsonResponse(true, [], 'تم تحديث المنتج بنجاح');
            }
            break;
            
        case 'delete':
            $id = $_POST['id'] ?? $_GET['id'] ?? 0;
            
            // Check if product is used in orders
            $stmt = $db->prepare("SELECT COUNT(*) as count FROM order_items WHERE product_id = ?");
            $stmt->execute([$id]);
            if ($stmt->fetch()['count'] > 0) {
                jsonResponse(false, [], 'لا يمكن حذف المنتج لأنه مستخدم في طلبات');
            }
            
            $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$id]);
            jsonResponse(true, [], 'تم حذف المنتج بنجاح');
            break;
            
        default:
            jsonResponse(false, [], 'إجراء غير صالح');
    }
} catch (PDOException $e) {
    jsonResponse(false, [], 'حدث خطأ: ' . $e->getMessage());
}
?>
