# 📊 بنية قاعدة البيانات - نظام إدارة اللانجري

## نظرة عامة

قاعدة البيانات `arabic_crm` تحتوي على 7 جداول رئيسية مع علاقات محكمة لضمان سلامة البيانات.

---

## 📋 الجداول

### 1. users - جدول المستخدمين

**الغرض:** إدارة حسابات المستخدمين والصلاحيات

| العمود | النوع | الوصف |
|--------|------|-------|
| id | INT | المعرف الفريد (Primary Key) |
| name | VARCHAR(100) | اسم المستخدم |
| email | VARCHAR(100) | البريد الإلكتروني (فريد) |
| password | VARCHAR(255) | كلمة المرور المشفرة |
| role | ENUM | الصلاحية (admin / staff) |
| created_at | TIMESTAMP | تاريخ الإنشاء |
| updated_at | TIMESTAMP | تاريخ آخر تعديل |

**Indexes:**
- PRIMARY KEY على `id`
- UNIQUE على `email`

**الافتراضي:**
```
email: admin@lingerie-store.com
password: password (مشفرة)
role: admin
```

---

### 2. products - جدول المنتجات

**الغرض:** تخزين معلومات المنتجات والمخزون

| العمود | النوع | الوصف |
|--------|------|-------|
| id | INT | المعرف الفريد |
| name | VARCHAR(200) | اسم المنتج |
| category | ENUM | الفئة (lingerie/pajamas/sets/accessories) |
| size | VARCHAR(20) | المقاس |
| color | VARCHAR(50) | اللون |
| sku | VARCHAR(50) | رمز المنتج الفريد |
| stock | INT | الكمية في المخزون |
| cost_price | DECIMAL(10,2) | سعر التكلفة |
| selling_price | DECIMAL(10,2) | سعر البيع |
| image | VARCHAR(500) | رابط صورة المنتج |
| notes | TEXT | ملاحظات |
| created_at | TIMESTAMP | تاريخ الإضافة |
| updated_at | TIMESTAMP | تاريخ التعديل |

**Indexes:**
- PRIMARY KEY على `id`
- UNIQUE على `sku`
- INDEX على `category`
- INDEX على `stock` (لسرعة البحث عن المخزون المنخفض)

**الحسابات:**
```sql
-- الربح من المنتج
profit_per_unit = selling_price - cost_price

-- قيمة المخزون
stock_value = stock * cost_price
```

---

### 3. customers - جدول العملاء

**الغرض:** إدارة بيانات العملاء

| العمود | النوع | الوصف |
|--------|------|-------|
| id | INT | المعرف الفريد |
| full_name | VARCHAR(200) | الاسم الكامل |
| phone | VARCHAR(20) | رقم الهاتف |
| address | TEXT | العنوان |
| city | VARCHAR(100) | المدينة |
| total_orders | INT | إجمالي عدد الطلبات |
| total_spent | DECIMAL(10,2) | إجمالي المبلغ المنفق |
| notes | TEXT | ملاحظات خاصة |
| created_at | TIMESTAMP | تاريخ التسجيل |
| updated_at | TIMESTAMP | تاريخ التعديل |

**Indexes:**
- PRIMARY KEY على `id`
- INDEX على `phone`
- INDEX على `city`

**التحديثات التلقائية:**
- يتم تحديث `total_orders` و `total_spent` تلقائياً عند إضافة طلب جديد

---

### 4. orders - جدول الطلبات

**الغرض:** تسجيل الطلبات الرئيسية

| العمود | النوع | الوصف |
|--------|------|-------|
| id | INT | المعرف الفريد |
| order_number | VARCHAR(50) | رقم الطلب الفريد |
| customer_id | INT | معرف العميل (FK) |
| status | ENUM | الحالة (new/processing/shipped/delivered/cancelled/returned) |
| order_date | DATETIME | تاريخ الطلب |
| shipping_method | ENUM | طريقة الشحن (standard/express/pickup) |
| shipping_cost | DECIMAL(10,2) | تكلفة الشحن |
| payment_method | ENUM | طريقة الدفع (cash/transfer/online) |
| discount | DECIMAL(10,2) | الخصم |
| notes | TEXT | ملاحظات |
| created_at | TIMESTAMP | تاريخ الإنشاء |
| updated_at | TIMESTAMP | تاريخ التعديل |

**Indexes:**
- PRIMARY KEY على `id`
- UNIQUE على `order_number`
- INDEX على `customer_id`
- INDEX على `status`
- INDEX على `order_date`

**Foreign Keys:**
- `customer_id` REFERENCES `customers(id)` ON DELETE RESTRICT

**تنسيق رقم الطلب:**
```
ORD-2024-0001
ORD-{YEAR}-{NUMBER}
```

---

### 5. order_items - جدول عناصر الطلبات

**الغرض:** تفاصيل كل منتج في الطلب

| العمود | النوع | الوصف |
|--------|------|-------|
| id | INT | المعرف الفريد |
| order_id | INT | معرف الطلب (FK) |
| product_id | INT | معرف المنتج (FK) |
| product_name | VARCHAR(200) | اسم المنتج (نسخة) |
| quantity | INT | الكمية |
| unit_price | DECIMAL(10,2) | سعر الوحدة |
| cost_price | DECIMAL(10,2) | سعر التكلفة |
| created_at | TIMESTAMP | تاريخ الإضافة |

**Indexes:**
- PRIMARY KEY على `id`
- INDEX على `order_id`
- INDEX على `product_id`

**Foreign Keys:**
- `order_id` REFERENCES `orders(id)` ON DELETE CASCADE
- `product_id` REFERENCES `products(id)` ON DELETE RESTRICT

**الحسابات:**
```sql
-- إجمالي العنصر
item_total = quantity * unit_price

-- ربح العنصر
item_profit = (unit_price - cost_price) * quantity
```

---

### 6. expenses - جدول المصروفات

**الغرض:** تسجيل جميع المصروفات

| العمود | النوع | الوصف |
|--------|------|-------|
| id | INT | المعرف الفريد |
| type | ENUM | نوع المصروف (shipping/advertising/packaging/photography/operational/other) |
| amount | DECIMAL(10,2) | المبلغ |
| expense_date | DATE | تاريخ المصروف |
| notes | TEXT | ملاحظات |
| created_at | TIMESTAMP | تاريخ التسجيل |
| updated_at | TIMESTAMP | تاريخ التعديل |

**Indexes:**
- PRIMARY KEY على `id`
- INDEX على `type`
- INDEX على `expense_date`

**أنواع المصروفات:**
- `shipping` - شحن
- `advertising` - إعلانات
- `packaging` - تغليف
- `photography` - تصوير
- `operational` - مصاريف تشغيلية
- `other` - أخرى

---

### 7. invoices - جدول الفواتير

**الغرض:** إصدار وتخزين الفواتير

| العمود | النوع | الوصف |
|--------|------|-------|
| id | INT | المعرف الفريد |
| invoice_number | VARCHAR(50) | رقم الفاتورة الفريد |
| order_id | INT | معرف الطلب (FK) |
| customer_name | VARCHAR(200) | اسم العميل |
| customer_phone | VARCHAR(20) | رقم الهاتف |
| customer_address | TEXT | العنوان |
| subtotal | DECIMAL(10,2) | المجموع الفرعي |
| discount | DECIMAL(10,2) | الخصم |
| shipping_cost | DECIMAL(10,2) | تكلفة الشحن |
| total | DECIMAL(10,2) | المجموع الكلي |
| payment_method | ENUM | طريقة الدفع |
| created_at | TIMESTAMP | تاريخ الإصدار |

**Indexes:**
- PRIMARY KEY على `id`
- UNIQUE على `invoice_number`
- INDEX على `order_id`

**Foreign Keys:**
- `order_id` REFERENCES `orders(id)` ON DELETE RESTRICT

**تنسيق رقم الفاتورة:**
```
INV-2024-0001
INV-{YEAR}-{NUMBER}
```

**الحسابات:**
```sql
total = subtotal - discount + shipping_cost
```

---

## 🔗 العلاقات بين الجداول

### مخطط العلاقات

```
customers (1) ----< orders (M)
    |
    |
    v
orders (1) ----< order_items (M) >---- products (1)
    |
    |
    v
orders (1) ----< invoices (1)
```

### التفاصيل:

**1. customers → orders**
- علاقة واحد لمتعدد (One-to-Many)
- عميل واحد يمكن أن يكون لديه عدة طلبات
- ON DELETE RESTRICT (لا يمكن حذف عميل لديه طلبات)

**2. orders → order_items**
- علاقة واحد لمتعدد (One-to-Many)
- طلب واحد يحتوي على عدة عناصر
- ON DELETE CASCADE (حذف الطلب يحذف عناصره)

**3. products → order_items**
- علاقة واحد لمتعدد (One-to-Many)
- منتج واحد يمكن أن يكون في عدة طلبات
- ON DELETE RESTRICT (لا يمكن حذف منتج مستخدم في طلبات)

**4. orders → invoices**
- علاقة واحد لواحد (One-to-One)
- كل طلب له فاتورة واحدة
- ON DELETE RESTRICT

---

## 📊 الاستعلامات الشائعة

### 1. حساب إجمالي مبيعات اليوم
```sql
SELECT 
    SUM(oi.quantity * oi.unit_price) as total_sales,
    SUM(o.shipping_cost) as total_shipping,
    SUM(o.discount) as total_discount
FROM orders o
LEFT JOIN order_items oi ON o.id = oi.order_id
WHERE DATE(o.order_date) = CURDATE()
AND o.status NOT IN ('cancelled', 'returned');
```

### 2. حساب صافي الربح
```sql
SELECT 
    (SUM(oi.quantity * oi.unit_price) + SUM(o.shipping_cost) - SUM(o.discount)) as revenue,
    SUM(oi.quantity * oi.cost_price) as cost,
    (SELECT SUM(amount) FROM expenses) as expenses,
    (
        (SUM(oi.quantity * oi.unit_price) + SUM(o.shipping_cost) - SUM(o.discount)) -
        SUM(oi.quantity * oi.cost_price) -
        (SELECT SUM(amount) FROM expenses)
    ) as net_profit
FROM orders o
LEFT JOIN order_items oi ON o.id = oi.order_id
WHERE o.status NOT IN ('cancelled', 'returned');
```

### 3. المنتجات الأكثر مبيعاً
```sql
SELECT 
    p.name,
    p.sku,
    SUM(oi.quantity) as total_sold,
    SUM(oi.quantity * oi.unit_price) as total_revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.id
JOIN orders o ON oi.order_id = o.id
WHERE o.status NOT IN ('cancelled', 'returned')
GROUP BY p.id
ORDER BY total_sold DESC
LIMIT 10;
```

### 4. أفضل العملاء
```sql
SELECT 
    c.*,
    COUNT(o.id) as order_count,
    SUM(
        (SELECT SUM(quantity * unit_price) FROM order_items WHERE order_id = o.id)
        + o.shipping_cost - o.discount
    ) as total_spent
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
WHERE o.status NOT IN ('cancelled', 'returned')
GROUP BY c.id
ORDER BY total_spent DESC
LIMIT 10;
```

### 5. المخزون بقيمته
```sql
SELECT 
    category,
    SUM(stock) as total_stock,
    SUM(stock * cost_price) as stock_value,
    SUM(stock * selling_price) as potential_revenue
FROM products
GROUP BY category;
```

---

## 🔒 الأمان

### 1. كلمات المرور
- مشفرة باستخدام `PASSWORD_HASH()` في PHP
- خوارزمية BCRYPT
- لا يمكن استرجاع كلمة المرور الأصلية

### 2. Prepared Statements
- جميع الاستعلامات تستخدم PDO Prepared Statements
- حماية من SQL Injection

### 3. الصلاحيات
- نظام صلاحيات بسيط (Admin / Staff)
- يمكن توسيعه لإضافة المزيد من الأدوار

---

## 📈 الأداء

### Indexes المطلوبة
جميع الـ Indexes مُعرّفة في `database.sql`:
- Primary Keys على جميع الجداول
- Foreign Keys مع Indexes
- Indexes على أعمدة البحث الشائعة

### نصائح التحسين
1. استخدم EXPLAIN للاستعلامات المعقدة
2. أضف Indexes حسب الحاجة
3. نظّف البيانات القديمة دورياً
4. استخدم Query Cache إن أمكن

---

## 🔄 النسخ الاحتياطي

### نسخ احتياطي كامل
```bash
mysqldump -u root -p arabic_crm > backup_$(date +%Y%m%d).sql
```

### استعادة من نسخة احتياطية
```bash
mysql -u root -p arabic_crm < backup_20240128.sql
```

### نسخ احتياطي جدول واحد
```bash
mysqldump -u root -p arabic_crm products > products_backup.sql
```

---

## 📝 ملاحظات مهمة

1. **Character Set:** UTF-8 (utf8mb4) لدعم العربية بشكل كامل
2. **Collation:** utf8mb4_unicode_ci للترتيب الصحيح
3. **Engine:** InnoDB لدعم Foreign Keys والمعاملات
4. **Timestamps:** تُحدّث تلقائياً

---

**نهاية وثيقة بنية قاعدة البيانات** 📊
