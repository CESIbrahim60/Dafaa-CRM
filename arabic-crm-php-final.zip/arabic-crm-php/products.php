<?php
require_once 'includes/config.php';
require_once 'includes/database.php';
require_once 'includes/functions.php';

requireLogin();

$db = getDB();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    $id = $_POST['product_id'] ?? 0;
    $name = sanitize($_POST['name'] ?? '');
    $category = $_POST['category'] ?? '';
    $size = sanitize($_POST['size'] ?? '');
    $color = sanitize($_POST['color'] ?? '');
    $sku = sanitize($_POST['sku'] ?? '');
    $stock = intval($_POST['stock'] ?? 0);
    $costPrice = floatval($_POST['cost_price'] ?? 0);
    $sellingPrice = floatval($_POST['selling_price'] ?? 0);
    $image = sanitize($_POST['image'] ?? '');
    $notes = sanitize($_POST['notes'] ?? '');
    
    try {
        if ($id > 0) {
            // Update
            $stmt = $db->prepare("
                UPDATE products 
                SET name = ?, category = ?, size = ?, color = ?, sku = ?, stock = ?, 
                    cost_price = ?, selling_price = ?, image = ?, notes = ?
                WHERE id = ?
            ");
            $stmt->execute([$name, $category, $size, $color, $sku, $stock, $costPrice, $sellingPrice, $image, $notes, $id]);
            setSuccessMessage('تم تحديث المنتج بنجاح');
        } else {
            // Add
            $stmt = $db->prepare("
                INSERT INTO products (name, category, size, color, sku, stock, cost_price, selling_price, image, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$name, $category, $size, $color, $sku, $stock, $costPrice, $sellingPrice, $image, $notes]);
            setSuccessMessage('تم إضافة المنتج بنجاح');
        }
        header('Location: products.php');
        exit;
    } catch (PDOException $e) {
        setErrorMessage('حدث خطأ: ' . $e->getMessage());
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    try {
        $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
        setSuccessMessage('تم حذف المنتج بنجاح');
        header('Location: products.php');
        exit;
    } catch (PDOException $e) {
        setErrorMessage('حدث خطأ أثناء الحذف');
    }
}

// Get products
$category = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';

$query = "SELECT * FROM products WHERE 1=1";
$params = [];

if (!empty($category)) {
    $query .= " AND category = ?";
    $params[] = $category;
}

if (!empty($search)) {
    $query .= " AND (name LIKE ? OR sku LIKE ? OR color LIKE ?)";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

$query .= " ORDER BY created_at DESC";

$stmt = $db->prepare($query);
$stmt->execute($params);
$products = $stmt->fetchAll();

// Get product for editing
$editProduct = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $editProduct = $stmt->fetch();
}

$pageTitle = 'المنتجات';
$currentPage = 'products';
include 'includes/header.php';
?>

<div class="page-header">
    <h1 class="page-title">المنتجات</h1>
    <button class="btn btn-primary" onclick="openModal('productModal')">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="12" y1="5" x2="12" y2="19"/>
            <line x1="5" y1="12" x2="19" y2="12"/>
        </svg>
        إضافة منتج جديد
    </button>
</div>

<?php if ($success = getSuccessMessage()): ?>
    <div class="alert alert-success">
        <span>✓</span>
        <span><?php echo $success; ?></span>
    </div>
<?php endif; ?>

<?php if ($error = getErrorMessage()): ?>
    <div class="alert alert-error">
        <span>✗</span>
        <span><?php echo $error; ?></span>
    </div>
<?php endif; ?>

<!-- Filters -->
<div class="card">
    <form method="GET" action="products.php">
        <div style="display: grid; grid-template-columns: 1fr 1fr auto; gap: 1rem; align-items: end;">
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">البحث</label>
                <input type="text" name="search" class="form-input" placeholder="ابحث بالاسم، SKU أو اللون" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">الفئة</label>
                <select name="category" class="form-select">
                    <option value="">الكل</option>
                    <option value="lingerie" <?php echo $category === 'lingerie' ? 'selected' : ''; ?>>لانجري</option>
                    <option value="pajamas" <?php echo $category === 'pajamas' ? 'selected' : ''; ?>>بيجامات</option>
                    <option value="sets" <?php echo $category === 'sets' ? 'selected' : ''; ?>>أطقم</option>
                    <option value="accessories" <?php echo $category === 'accessories' ? 'selected' : ''; ?>>إكسسوارات</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary">بحث</button>
        </div>
    </form>
</div>

<!-- Products Table -->
<div class="card">
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>الصورة</th>
                    <th>الاسم</th>
                    <th>الفئة</th>
                    <th>المقاس</th>
                    <th>اللون</th>
                    <th>SKU</th>
                    <th>المخزون</th>
                    <th>سعر التكلفة</th>
                    <th>سعر البيع</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td>
                            <?php if ($product['image']): ?>
                                <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                                     alt="<?php echo htmlspecialchars($product['name']); ?>"
                                     class="product-image">
                            <?php else: ?>
                                <div class="product-image" style="background: #f3f4f6;"></div>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td><?php echo getCategoryLabel($product['category']); ?></td>
                        <td><?php echo htmlspecialchars($product['size']); ?></td>
                        <td><?php echo htmlspecialchars($product['color']); ?></td>
                        <td><?php echo htmlspecialchars($product['sku']); ?></td>
                        <td>
                            <span style="color: <?php echo $product['stock'] <= 10 ? '#dc2626' : '#059669'; ?>; font-weight: bold;">
                                <?php echo $product['stock']; ?>
                            </span>
                        </td>
                        <td><?php echo formatCurrency($product['cost_price']); ?></td>
                        <td><?php echo formatCurrency($product['selling_price']); ?></td>
                        <td>
                            <a href="products.php?edit=<?php echo $product['id']; ?>" class="btn btn-primary btn-sm">
                                تعديل
                            </a>
                            <a href="products.php?delete=<?php echo $product['id']; ?>" 
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('هل أنت متأكد من الحذف؟')">
                                حذف
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="10" style="text-align: center;">لا توجد منتجات</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Product Modal -->
<div id="productModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 class="modal-title"><?php echo $editProduct ? 'تعديل منتج' : 'إضافة منتج جديد'; ?></h2>
            <button type="button" class="modal-close" onclick="closeModal('productModal')">&times;</button>
        </div>
        
        <form method="POST" action="products.php">
            <input type="hidden" name="product_id" value="<?php echo $editProduct['id'] ?? ''; ?>">
            
            <div class="form-group">
                <label class="form-label">اسم المنتج *</label>
                <input type="text" name="name" class="form-input" required value="<?php echo htmlspecialchars($editProduct['name'] ?? ''); ?>">
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label">الفئة *</label>
                    <select name="category" class="form-select" required>
                        <option value="">اختر الفئة</option>
                        <option value="lingerie" <?php echo ($editProduct['category'] ?? '') === 'lingerie' ? 'selected' : ''; ?>>لانجري</option>
                        <option value="pajamas" <?php echo ($editProduct['category'] ?? '') === 'pajamas' ? 'selected' : ''; ?>>بيجامات</option>
                        <option value="sets" <?php echo ($editProduct['category'] ?? '') === 'sets' ? 'selected' : ''; ?>>أطقم</option>
                        <option value="accessories" <?php echo ($editProduct['category'] ?? '') === 'accessories' ? 'selected' : ''; ?>>إكسسوارات</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">المقاس *</label>
                    <input type="text" name="size" class="form-input" required value="<?php echo htmlspecialchars($editProduct['size'] ?? ''); ?>">
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label">اللون *</label>
                    <input type="text" name="color" class="form-input" required value="<?php echo htmlspecialchars($editProduct['color'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label">SKU *</label>
                    <input type="text" name="sku" class="form-input" required value="<?php echo htmlspecialchars($editProduct['sku'] ?? ''); ?>">
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label">المخزون</label>
                    <input type="number" name="stock" class="form-input" min="0" value="<?php echo $editProduct['stock'] ?? 0; ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label">سعر التكلفة</label>
                    <input type="number" step="0.01" name="cost_price" class="form-input" min="0" value="<?php echo $editProduct['cost_price'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label">سعر البيع</label>
                    <input type="number" step="0.01" name="selling_price" class="form-input" min="0" value="<?php echo $editProduct['selling_price'] ?? ''; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label">رابط الصورة</label>
                <input type="url" name="image" class="form-input" value="<?php echo htmlspecialchars($editProduct['image'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label class="form-label">ملاحظات</label>
                <textarea name="notes" class="form-textarea"><?php echo htmlspecialchars($editProduct['notes'] ?? ''); ?></textarea>
            </div>
            
            <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                <button type="button" class="btn btn-secondary" onclick="closeModal('productModal')">إلغاء</button>
                <button type="submit" class="btn btn-primary">حفظ</button>
            </div>
        </form>
    </div>
</div>

<?php if ($editProduct): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    openModal('productModal');
});
</script>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
