<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - <?php echo SITE_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-card fade-in">
            <div class="login-header">
                <h1 class="login-title">نظام إدارة لانجري</h1>
                <p class="login-subtitle">مرحباً بك، يرجى تسجيل الدخول للمتابعة</p>
            </div>
            
            <?php if ($error = getErrorMessage()): ?>
                <div class="alert alert-error">
                    <span>✗</span>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="login.php">
                <div class="form-group">
                    <label for="email" class="form-label">البريد الإلكتروني</label>
                    <input type="email" id="email" name="email" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label for="password" class="form-label">كلمة المرور</label>
                    <input type="password" id="password" name="password" class="form-input" required>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    تسجيل الدخول
                </button>
            </form>
            
            <div style="margin-top: 1.5rem; text-align: center; color: #666; font-size: 0.9rem;">
                <p>البيانات الافتراضية:</p>
                <p>البريد: admin@lingerie-store.com</p>
                <p>كلمة المرور: password</p>
            </div>
        </div>
    </div>
</body>
</html>
