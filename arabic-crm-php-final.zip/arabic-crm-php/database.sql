-- قاعدة بيانات نظام إدارة علاقات العملاء للانجري
-- Arabic CRM Database Schema

CREATE DATABASE IF NOT EXISTS arabic_crm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE arabic_crm;

-- جدول المستخدمين
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'staff') DEFAULT 'staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول المنتجات
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    category ENUM('lingerie', 'pajamas', 'sets', 'accessories') NOT NULL,
    size VARCHAR(20) NOT NULL,
    color VARCHAR(50) NOT NULL,
    sku VARCHAR(50) UNIQUE NOT NULL,
    stock INT DEFAULT 0,
    cost_price DECIMAL(10, 2) NOT NULL,
    selling_price DECIMAL(10, 2) NOT NULL,
    image VARCHAR(500),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_sku (sku),
    INDEX idx_stock (stock)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول العملاء
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(200) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    city VARCHAR(100),
    total_orders INT DEFAULT 0,
    total_spent DECIMAL(10, 2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_phone (phone),
    INDEX idx_city (city)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الطلبات
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id INT NOT NULL,
    status ENUM('new', 'processing', 'shipped', 'delivered', 'cancelled', 'returned') DEFAULT 'new',
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    shipping_method ENUM('standard', 'express', 'pickup') DEFAULT 'standard',
    shipping_cost DECIMAL(10, 2) DEFAULT 0,
    payment_method ENUM('cash', 'transfer', 'online') DEFAULT 'cash',
    discount DECIMAL(10, 2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE RESTRICT,
    INDEX idx_order_number (order_number),
    INDEX idx_customer_id (customer_id),
    INDEX idx_status (status),
    INDEX idx_order_date (order_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول عناصر الطلبات
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    cost_price DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
    INDEX idx_order_id (order_id),
    INDEX idx_product_id (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول المصروفات
CREATE TABLE expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('shipping', 'advertising', 'packaging', 'photography', 'operational', 'other') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    expense_date DATE NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_type (type),
    INDEX idx_expense_date (expense_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الفواتير
CREATE TABLE invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    order_id INT NOT NULL,
    customer_name VARCHAR(200) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    customer_address TEXT,
    subtotal DECIMAL(10, 2) NOT NULL,
    discount DECIMAL(10, 2) DEFAULT 0,
    shipping_cost DECIMAL(10, 2) DEFAULT 0,
    total DECIMAL(10, 2) NOT NULL,
    payment_method ENUM('cash', 'transfer', 'online') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE RESTRICT,
    INDEX idx_invoice_number (invoice_number),
    INDEX idx_order_id (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- بيانات تجريبية للمستخدمين
INSERT INTO users (name, email, password, role) VALUES
('أميرة محمد', 'admin@lingerie-store.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
-- كلمة المرور: password

-- بيانات تجريبية للمنتجات
INSERT INTO products (name, category, size, color, sku, stock, cost_price, selling_price, image, notes) VALUES
('طقم لانجري دانتيل أسود', 'lingerie', 'M', 'أسود', 'LNG-001', 25, 150.00, 299.00, 'https://images.unsplash.com/photo-1616530940355-351fabd9524b?w=200', 'منتج مميز - الأكثر مبيعاً'),
('بيجامة ستان وردي', 'pajamas', 'L', 'وردي', 'PJM-001', 18, 120.00, 249.00, 'https://images.unsplash.com/photo-1564584217132-2271feaeb3c5?w=200', ''),
('طقم لانجري أحمر مع روب', 'sets', 'S', 'أحمر', 'SET-001', 5, 200.00, 399.00, 'https://images.unsplash.com/photo-1617331721458-bd3bd3f9c7f8?w=200', 'مخزون منخفض'),
('بيجامة قطن مريحة', 'pajamas', 'XL', 'بيج', 'PJM-002', 30, 80.00, 179.00, 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=200', ''),
('لانجري دانتيل أبيض عروس', 'lingerie', 'M', 'أبيض', 'LNG-002', 12, 180.00, 349.00, 'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?w=200', 'مناسب للعرائس'),
('روب ستان طويل', 'accessories', 'L', 'عنابي', 'ACC-001', 8, 100.00, 199.00, 'https://images.unsplash.com/photo-1582719471384-894fbb16e074?w=200', '');

-- بيانات تجريبية للعملاء
INSERT INTO customers (full_name, phone, address, city, total_orders, total_spent, notes) VALUES
('سارة محمد أحمد', '01012345678', 'شارع التحرير، المعادي', 'القاهرة', 5, 1499.00, 'VIP - عميلة مميزة'),
('نورا علي حسن', '01198765432', 'شارع الهرم', 'الجيزة', 3, 897.00, ''),
('مريم خالد عبدالله', '01234567890', 'سيدي جابر', 'الإسكندرية', 7, 2198.00, 'عميلة متكررة - تفضل الألوان الداكنة'),
('هدى أحمد سعيد', '01087654321', 'شارع الملك فيصل', 'الجيزة', 2, 548.00, ''),
('فاطمة محمود حسين', '01156789012', 'مدينة نصر', 'القاهرة', 4, 1196.00, 'تفضل المقاسات الكبيرة');

-- بيانات تجريبية للمصروفات
INSERT INTO expenses (type, amount, expense_date, notes) VALUES
('advertising', 500.00, '2024-03-01', 'إعلانات فيسبوك'),
('packaging', 200.00, '2024-03-05', 'أكياس وعلب تغليف'),
('shipping', 300.00, '2024-03-10', 'تكاليف شحن إضافية'),
('photography', 400.00, '2024-03-12', 'تصوير منتجات جديدة'),
('operational', 150.00, '2024-03-15', 'مصاريف إدارية');
